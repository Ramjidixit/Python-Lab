r=int(input("enter the radius of circle"))
pi=3.14
area=pi*r*r
print("the area of the circle is = ",area)
